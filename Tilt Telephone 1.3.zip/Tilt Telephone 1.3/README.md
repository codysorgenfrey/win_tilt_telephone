# Tilt Telephone
A windows utility for logging Tilt Hydrometer readings to the cloud.

## Installation
1. Copy the folder `Tilt Telephone` that contains `tilt-telephone.exe` into your `Program Files` folder. 
2. Configure the json file for your specific tilt and brew.
3. Run `tilt-telephone.exe`.

## Repeat flag
If you'd like the utility to run every `x` minutes add the commandline flag `-repeat={number of minutes}`.  
An example command would look like this:
```
C:\Program Files\Tilt Telephone\tilt-telephone.exe -repeat=15
```
This would log the readings to the cloud every 15 minutes.

## Scheduling the task in the background
I reccomend setting up a scheduled task that runs the app automatically in the background so you don't have to remember to run the utility every so often. Here's how to set that up:

1. Make sure you've configured the settings and the utility is working, see usage for details.
2. From the Start menu launch "Task Scheduler".
3. From the Action menu select "Create Basic Task..."
4. Give the task a name and description of your liking. Hit Next.
5. Leave trigger set to Daily. Hit Next.
6. Set the start date to today, and time to some time in the future (when you'll be done with this setup, I reccomend now+5 minutes). Hit Next. (Note you can leave Recur set to 1 day for now).
7. Select Start a Program. Hit Next.
8. Enter the Following:
    1. Program: `cmd`
    2. Add arguments: `/c "C:\Program Files\Tilt Telephone\tilt-telephone.exe" >> "C:\Program Files\Tilt Telephone\log.txt"`
9. Hit Next.
10. Check "Open the properties dialog for this task when I hit finish"
11. Hit Finish.
12. Under the "Triggers" tab in the resulting dialog, double click the row that says "Daily".
13. Check "Repeat task every" and set interval. (I reccomend every 15 or 30 minutes). Set "For a duration of" to "Indefinitely".
14. Click Ok.
15. Click Ok again.

Now your scheduled task should run however often you set. You can check that it ran in the output log file located in `C:\Program Files\Tilt Telephone\log.txt`.

## Settings
Settings for the utility are defined in the `tilt-telephone.json` file located in the same directory as `tilt-telephone.exe`. 

### tilt-telephone.json
Each entry in the json file represents the settings for a tilt of that color. If you don't have a tilt of said color, you can remove that entry so the utility won't waste time looking for it.

The following are the settings found in the json file and what they do.

1. uuid - don't touch this, it's the unique key for each color tilt.
2. color - again, tilt's color is tied to it's uuid, don't change this.
3. name - the unique name of you beer, and also usually followed by an ID number. Get this string from the tilt phone app when you set up the tilt for a new brew.
4. tempCali - a list of objects that represent calibration points. Each "point" has a `precal` and `corrected` field that are used to calibrate the reading.
5. sgCali - a list of objects that represent calibration points. Each "point" has a `precal` and `corrected` field that are used to calibrate the reading.
6. loggingURL - the url of the cloud service to log the tilt readings to. Unfortunetly there isn't a way to get the "default cloud logging url" from the tilt app, so you'll need to set up the google sheet and script yourself to get a custom logging url, or use a 3rd party service like Brewfather. See [Custom cloud logging.](https://docs.google.com/spreadsheets/d/1ut1wClRrowkYRYm6yQAVuc_Q568stncawv1EuYez2go/edit?usp=sharing)
7. connectionTimeout - how long to let the app look for the tilt before giving up in milliseconds.

Here is an example `tilt-telephone.json`:
```json
[
    {
        "uuid": "30bb95a4-b1c5-444b-b512-1370f02d74de",
        "color": "black",
        "name": "Other Half Daydream,64544",
        "tempCali": [
            { "precal": 60.0, "corrected": 61.0 }
        ],
        "sgCali": [
            { "precal": 0.999, "corrected": 1.000 }
        ],
        "loggingURL": "https://script.google.com/...",
        "connectionTimeout": 60000
    }
]
```
As you can see, this file only declares one tilt, and has it's specific info filled out. In this case there's only one calibration point in both the temprature and SG fields.